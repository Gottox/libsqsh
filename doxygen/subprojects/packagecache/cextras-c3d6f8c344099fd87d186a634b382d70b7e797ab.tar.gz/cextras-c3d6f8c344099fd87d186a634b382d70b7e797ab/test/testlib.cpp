/**
 * @author      : Enno Boland (mail@eboland.de)
 * @file        : testlib
 * @created     : Tuesday Jul 25, 2023 13:56:58 CEST
 */

#include <testlib.h>

static void
test1(void) {}

DECLARE_TESTS
TEST(test1)
END_TESTS
