# cextras

A set of generic functions that can be used in multiple projects.

# Usage

subproject/cextras.wrap:
```ini
[wrap-git]
url=https://github.com/Gottox/cextras.git
revision=main
depth=1

[provide]
cextras=cextras_dep
testlib=testlib_dep
```
